/**
 * Reference for Test files
 **/
require('tests/test_index');

/**
 * Modular for url's
 **/
var CONFIG_URL = require('config');

/**
 * Create the widget for reference
 */
var initLoader = Alloy.createWidget('ActivityIndicator');

/**
 * Connectivity check declared
 */
var connectivityCheckResult = connectivityCheck();

/**
 * Widget header parameters
 **/
$.applicationHeader.init($.slideMenu, $.webWrapper);
$.slideMenu.init($.applicationHeader, $.slideMenu, $.webWrapper);

/**
 * @param {String} url - The static URL to open in the webview
 * Network check
 */
if (connectivityCheckResult.status == true) {
	$.webWrapper.url = CONFIG_URL.URL_HOME;
} else {

	Ti.API.info("index :- network error");
	showAlert(L("noNetwork"), L("errorTitle"), L("okLbl"));
}

/**
 * Firing event only for android & iOS handling default
 */
if (Alloy.Globals.isAndroid) {

	$.webWrapper.addEventListener('beforeload', function(e) {
		Ti.API.info("index :- loader initiated");
		initLoader.showIndicator();
	});

	$.webWrapper.addEventListener('load', function(e) {
		Ti.API.info("index :- loader closed once page loaded");
		initLoader.hideIndicator();
	});

	$.webWrapper.addEventListener('error', function(e) {
		Ti.API.info("index :- loader closed when error comes");
		initLoader.hideIndicator();
	});

	$.webWrapper.addEventListener('sslerror', function(e) {
		Ti.API.info("index :- loader closed when ssl error comes");
		initLoader.hideIndicator();
	});
}

/**
 * When necessary possible to remove Webview
 */
function cleanUp() {
	if ($.webWrapper != null) {
		$.win.remove($.webWrapper);
		$.webWrapper.release();
	}
	$.webWrapper = null;
	button.removeEventListener('click', buttonClicked);
	Ti.App.removeEventListener('app:fromWebView', $.webWrapper);
	Ti.App.fireEvent('app:fromTitanium', {
		message : 'event fired from Titanium, after removing WebView'
	});
}

/**
 *  Android Hardware button disable call
 **/
disableHardwareButton($.win);

/**
 *  Open window
 **/
$.win.open();
