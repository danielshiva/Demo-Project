/**
 * Reference for Test files
 **/
require('tests/test_hamburgerMenu');

/**
 * Modular for animate slide
 **/
var initAnimateSlide = require('animateSlide');

/**
 * This source is for slide menu widget initialization
 */
$.init = function(slideMenu, webWrapper) {

	/**
	 * slide animation based in menu click
	 */
	$.menuBtn.addEventListener("click", function(_event) {
		Ti.API.info("Menu button clicked :- Menu Moving right");

		/**
		 * Slide animation call
		 **/
		initAnimateSlide.animateSlide($.headerContainerId, webWrapper, slideMenu);

	});
};

/**
 * Search method
 */
function searchData() {
	showAlert(L("searchDesc"), L("searchTitle"), L("okLbl"));
}
