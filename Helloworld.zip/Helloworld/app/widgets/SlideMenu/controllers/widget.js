/**
 * Reference for Test files
 **/
require('tests/test_slideMenu');

/**
 * Modular for API url's & animate slide
 **/
var CONFIG_URL = require('config');
var initAnimateSlide = require('animateSlide');

/**
 * Create the widget for reference
 */
var _openModalWebview = Alloy.createWidget('ModalWebview');

/**
 * init Array for menu data
 */
var menuListData = [];

/**
 * This source is for slide menu widget initialization
 */
$.init = function(applicationHeader, slideMenu, webWrapper) {

	/**
	 * Assigned values to Array for binding
	 */
	menuListData = [{
		"menuLbl" : {
			text : L('home')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('latestNews')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('comics')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('movies')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('videos')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('games')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('tv')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('characters')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('shop')
		},
		"template" : "list_template"

	}, {
		"menuLbl" : {
			text : L('help')
		},
		"template" : "list_template"
	}];

	/**
	 *  Binding data to the listview
	 **/
	$.menuListView.sections[0].setItems(menuListData, {
		animated : "false"
	});

	/**
	 *  GET MENU CLICK ITEM
	 **/
	$.menuListView.addEventListener("itemclick", function(_event) {
		var itemIndex = _event.itemIndex;

		switch(itemIndex) {

		case 0:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_HOME, L('home'));
			Ti.API.info("Menu itemclick 0 clicked :- ");

			break;
		case 1:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_LATEST_NEWS, L('latestNews'));
			Ti.API.info("Menu itemclick 1 clicked :- ");

			break;
		case 2:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_COMICS, L('comics'));
			Ti.API.info("Menu itemclick 2 clicked :- ");

			break;
		case 3:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_MOVIES, L('movies'));
			Ti.API.info("Menu itemclick 3 clicked :- ");

			break;
		case 4:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_VIDEOS, L('videos'));
			Ti.API.info("Menu itemclick 4 clicked :- ");

			break;
		case 5:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_GAMES, L('games'));
			Ti.API.info("Menu itemclick 5 clicked :- ");

			break;
		case 6:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_TV, L('tv'));
			Ti.API.info("Menu itemclick 6 clicked :- ");

			break;
		case 7:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_CHARACTERS, L('characters'));
			Ti.API.info("Menu itemclick 7 clicked :- ");

			break;
		case 8:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_SHOP, L('shop'));
			Ti.API.info("Menu itemclick 8 clicked :- ");

			break;
		case 9:
			/**
			 *  OPEN MODAL WEBVIEW
			 **/
			_openModalWebview.openWebviewModal(CONFIG_URL.URL_HELP, L('help'));
			Ti.API.info("Menu itemclick 9 clicked :- ");

			break;
		default:
			//do nothing here
			break;
		}

		/**
		 * Close slide menu call once selected any option
		 */
		initAnimateSlide.closeSlideMenu(applicationHeader, webWrapper, slideMenu);

	});
};

