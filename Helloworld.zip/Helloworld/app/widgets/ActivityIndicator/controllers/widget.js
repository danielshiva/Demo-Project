function showIndicator() {
	$.container.open();
}

function hideIndicator() {
	$.container.close();
}

/**
 * Below function is responsible for disabling android back button.
 **/
if (Alloy.Globals.isAndroid) {
	$.container.addEventListener("android:back", function(e) {
		//Do something here
	});
}

exports.showIndicator = showIndicator;
exports.hideIndicator = hideIndicator;

