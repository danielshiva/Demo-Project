/**
 * Reference for Test files
 **/
require('tests/test_modalWebview');

/**
 * Create the widget for reference
 */
var XHRHttpReference = Alloy.createWidget('Webservice');
var initLoader = Alloy.createWidget('ActivityIndicator');

/**
 * Connectivity check declared
 */
var connectivityCheckResult = connectivityCheck();

/**
 * Define your success callback
 */
XHRHttpReference.success = function(resData) {
	//Ti.API.info('response success --> ' + resData);	// Commented for time taken for load data

	//	hide loader call
	hideAndroidIndicator();

	/**
	 * @ set HTML
	 **/
	$.webview.html = resData;
};

/**
 * Define your error callback
 */
XHRHttpReference.error = function(resError) {

	//	hide loader call
	hideAndroidIndicator();

	showAlert(L("unloadPage"), L("errorTitle"), L("okLbl"));
};

/**
 * Opens the window and the contained webview to access URL
 * @Public
 *
 * @param {String} url - The URL to open in the webview
 */
function _openWebviewModal(url, headerTitle) {

	/**
	 * @ setting header title for modal window
	 **/
	$.title.text = headerTitle;

	if (connectivityCheckResult.status == true) {
		/**
		 *  XHR HTTP client call
		 **/
		XHRHTTPClientCAll(url);

		/**
		 * Open the modal window
		 */
		$.win.open({
			modal : true
		});

	} else {
		showAlert(L("noNetwork"), L("errorTitle"), L("okLbl"));
	}
}

/**
 * Public interface for the `_open` function.
 */
exports.openWebviewModal = _openWebviewModal;

/**
 * Closes the modal window and resets the webview url.
 * @private
 */
function _close() {
	Ti.API.info('Deallocating WebView ');
	$.webview.url = "";
	$.win.close();
}

/**
 * Public interface for the `_close` function.
 */
exports.close = _close;

/**
 * Closes the modal dialog
 * @private
 */
function _onClickCloseButton(e) {
	_close();
}

/**
 *  XHR HTTP client method
 **/
function XHRHTTPClientCAll(configUrl) {
	//show loader call
	showAndroidIndicator();

	/**
	 * XHR input parameter
	 */
	var xhrInputParams = {
		reqURL : configUrl,
		reqMethod : 'GET',
		reqParams : null,
	};

	/**
	 * To use the widget, just call the `XHRClientauthorize` function.
	 */
	XHRHttpReference.XHRClientauthorize(xhrInputParams);
};

/**
 * show loader for android
 */
function showAndroidIndicator() {
	if (Alloy.Globals.isAndroid) {
		Ti.API.info("API call :- loader initiated");
		initLoader.showIndicator();
	} else {
		Ti.API.info("iOS :- No need to show Loader");
	}
}

/**
 * hide loader for android
 */
function hideAndroidIndicator() {
	if (Alloy.Globals.isAndroid) {
		Ti.API.info("API call :- loader closed when Success or error returns");
		initLoader.hideIndicator();
	} else {
		Ti.API.info("iOS :- No need to show Loader");
	}
}

/**
 *  Android Hardware button disable call
 **/
disableHardwareButton($.win);
