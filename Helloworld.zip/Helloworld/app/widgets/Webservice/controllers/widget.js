/**
 * Reference for Test files
 **/
require('tests/test_webservice');

var _onSuccess, // <-- Callback for success
    _onError;
// <-- Callback for errors

/**
 * XHR client for authentication.
 * @public
 */
function _XHRClientauthorize(args) {

	_XHRServiceCall(args, function(err, result) {
		if (err) {
			_onError && _onError(err) || Ti.API.error(err.message);
		} else {
			_onSuccess && _onSuccess(result);
		}
	});
}

/**
 * Public interface for calling XHR
 */
exports.XHRClientauthorize = _XHRClientauthorize;

/**
 * Retrieves the response
 * @private
 *
 */
function _XHRServiceCall(args, callback) {
	/**
	 * getting parameter
	 */
	var reqURL = args.reqURL;
	var reqMethod = args.reqMethod;
	var reqParams = args.reqParams;

	Ti.API.info("XHR API Params :-- reqURL	" + reqURL);
	Ti.API.info("XHR API Params :-- reqMethod	" + reqMethod);
	Ti.API.info("XHR API Params :-- reqParams	" + reqParams);

	if (reqURL) {

		/**
		 * Make Request to get the response
		 */
		var xhr = Ti.Network.createHTTPClient({
			onload : function(e) {

				/**
				 * Success! Return the response
				 */
				if (this.status == 200) {
					var response = this.responseText;

					callback && callback(null, response);
				}
			},
			onerror : function(e) {

				/**
				 * Oops! Something went wrong here
				 */
				callback && callback(e.error);
			},
			timeout : 10000
		});
		xhr.open(reqMethod, reqURL);
		xhr.send();
	}
}

/**
 * onSuccess callback Property
 */
Object.defineProperty($, 'success', {
	get : function _getSuccessCallback() {
		return _onSuccess;
	},
	set : function _setSuccessCallback(func) {
		if (_.isFunction(func)) {
			_onSuccess = func;
		} else {
			Ti.API.error('Error setting property - onSuccess must be a function.');
		}
	}
});

/**
 * onError callback Property
 */
Object.defineProperty($, 'error', {
	get : function _getErrorCallback() {
		return _onError;
	},
	set : function _setErrorCallback(func) {
		if (_.isFunction(func)) {
			_onError = func;
		} else {
			Ti.API.error('Error setting property - onError must be a function.');
		}
	}
});

