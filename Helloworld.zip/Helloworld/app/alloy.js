/**
 * Set Default Bool for android
 **/
Alloy.Globals.isAndroid = false;

/**
 * Checking OS type
 **/
if (Ti.Platform.osname == 'android') {
	Alloy.Globals.isAndroid = true;
} else if (Ti.Platform.osname == 'iphone') {
	Alloy.Globals.isIOS = true;
}

/**
 * Connectivity check
 **/
function connectivityCheck() {
	if (Titanium.Network.NETWORK_NONE) {
		return {
			status : false,
			type : "NONE"
		};
	} else if (Titanium.Network.online) {
		if (Titanium.Network.networkType == Titanium.Network.NETWORK_LAN) {
			return {
				status : true,
				type : "LAN"
			};
		}
		if (Titanium.Network.networkType == Titanium.Network.NETWORK_WIFI) {
			return {
				status : true,
				type : "WIFI"
			};
		}
		if (Titanium.Network.networkType == Titanium.Network.NETWORK_MOBILE) {
			return {
				status : true,
				type : "MOBILE"
			};
		}
		if (Titanium.Network.networkType == Titanium.Network.NETWORK_UNKNOWN) {
			return {
				status : true,
				type : "UNKNOWN"
			};
		}
	} else {
		return {
			status : false,
			type : "NONE"
		};
	}
}

/**
 * Error Alert dialog
 **/
function showAlert(message, title, ok) {
	Ti.UI.createAlertDialog({
		message : message,
		title : title,
		ok : ok
	}).show();
}

/**
 * Disable android hardware device button, since using webview
 **/
function disableHardwareButton(hardwareBtn) {
	if (Alloy.Globals.isAndroid) {
		hardwareBtn.addEventListener("android:back", function(e) {
			e.cancelBubble = true;
			//	prevent the back-button default action
		});
	} else {
		Ti.API.info("Hardware button iOS:- Not applicable");
	}
}
